package com.writternoted.writternotedfree.listeners;

import com.writternoted.writternotedfree.entities.Category;

public interface ChooseCategoryListener {
    void onCategoryClicked(Category category, int position);
}
