package com.writternoted.writternotedfree.listeners;

import com.writternoted.writternotedfree.entities.Category;

public interface CategoriesListener {
    void onCategoryDeleteClicked(Category category, int position);

    void onCategoryEditClicked(Category category, int position);
}
