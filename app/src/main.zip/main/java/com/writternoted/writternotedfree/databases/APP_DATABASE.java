package com.writternoted.writternotedfree.databases;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.writternoted.writternotedfree.entities.ArchiveNote;
import com.writternoted.writternotedfree.entities.Category;
import com.writternoted.writternotedfree.entities.Note;
import com.writternoted.writternotedfree.entities.Notification;
import com.writternoted.writternotedfree.entities.Todo;
import com.writternoted.writternotedfree.entities.TodosList;
import com.writternoted.writternotedfree.entities.TrashNote;

@Database(
        entities = {
                Note.class,
                ArchiveNote.class,
                Category.class,
                Notification.class,
                TrashNote.class,
                Todo.class,
                TodosList.class
        },
        version = 2,
        exportSchema = false)
public abstract class APP_DATABASE extends RoomDatabase {

    public abstract DAO dao();

    private static APP_DATABASE appDatabase;

    public static synchronized APP_DATABASE requestDatabase(Context context) {
        if (appDatabase == null) {
            appDatabase = Room.databaseBuilder(context, APP_DATABASE.class, "noted_database")
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return appDatabase;
    }

    public static void destroyDatabase() {
        appDatabase = null;
    }
}
