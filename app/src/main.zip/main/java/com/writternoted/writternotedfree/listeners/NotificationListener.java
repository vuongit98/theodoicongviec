package com.writternoted.writternotedfree.listeners;

import com.writternoted.writternotedfree.entities.Notification;

public interface NotificationListener {
    void onNotificationClicked(Notification notification, int position);
}
