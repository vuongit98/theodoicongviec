package com.writternoted.writternotedfree.listeners;

import com.writternoted.writternotedfree.entities.Category;

public interface ChipCategoryListener {
    void onCategoryClicked(Category category, int position);
}
