package com.writternoted.writternotedfree.listeners;

import com.writternoted.writternotedfree.entities.ArchiveNote;

public interface ArchiveNotesListener {
    void onNoteClicked(ArchiveNote archive_note, int position);

    void onNoteLongClicked(ArchiveNote archive_note, int position);
}
