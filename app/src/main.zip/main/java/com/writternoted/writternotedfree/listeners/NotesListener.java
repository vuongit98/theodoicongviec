package com.writternoted.writternotedfree.listeners;

import com.writternoted.writternotedfree.entities.Note;

public interface NotesListener {
    void onNoteClicked(Note note, int position);

    void onNoteLongClicked(Note note, int position);
}
