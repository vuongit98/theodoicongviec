package com.writternoted.writternotedfree.listeners;

import com.writternoted.writternotedfree.entities.Note;

public interface NotesActionListener {
    void onNoteAction(Note note, int position, boolean isSelected);
}
