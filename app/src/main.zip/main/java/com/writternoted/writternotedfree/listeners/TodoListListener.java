package com.writternoted.writternotedfree.listeners;

import com.writternoted.writternotedfree.entities.TodosList;

public interface TodoListListener {
    void onTodoListClicked(TodosList todosList, int position);
}
