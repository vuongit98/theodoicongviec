package com.writternoted.writternotedfree.listeners;

import com.writternoted.writternotedfree.entities.TrashNote;

public interface TrashNotesListener {
    void onNoteClicked(TrashNote trashNote, int position);

    void onNoteLongClicked(TrashNote trashNote, int position);
}
