package com.writternoted.billing;

public class Config {
  // change KEY
    public static final String IAP_LISENCE_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2CkNSlZKHCc+fABlgOmAw/c5077tWYVdSHFJES/pOet1xIUQ0cp6JqiE8P4sw25GSiMsodwsYGjObWk0RhELl140CKvJYOT7XaRcSHHjMfnxeHfqp/hqYaxijKnyMZ/Q2CaxRsSwwEGDjCvs//l8cCiaJdhYt58Lm1rS88kFZHmlCMOwZj8Cw1RTD7WxZqlpO3XdxovIw1P+tXPQhJJWgOzCC8Mo6SJ43HBmUAKg9Ke0d6MjdIb3OAT/rxAMajYcHuDJiaPOsWa37adQiHn+x5V9QiGh6UCLx+KRKk/HGi1lIDwhg8ZzHTTk3rOQhz8rADXT42XftoglePi/LD3bOwIDAQAB";
    // Subscriptions id
    public static final String A_WEEK = "in_a_week";
    public static final String A_MONTH = "in_a_month";
    public static final String SIX_MONTH = "in_six_month";


    public static final String SUB_ITEM = "sub_item_1";

    // In APP id
    public static final String ITEM_1 = "consumer_item_1";
    public static final String ITEM_2 = "consumer_item_2";
    public static final String ITEM_3 = "consumer_item_3";
    public static final String ITEM_4 = "consumer_item_4";
    public static final String ITEM_5 = "consumer_item_5";

    // Type In App
    public static final String CONSUMER = "CONSUMER";
    public static final String NON_CONSUMER = "NON_CONSUMER";

    public static final String TOTAL_COUNT = "TOTAL_COUNT";

}