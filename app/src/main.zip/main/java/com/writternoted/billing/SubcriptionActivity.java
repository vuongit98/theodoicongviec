package com.writternoted.billing;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.writternoted.writternotedfree.R;

import java.util.ArrayList;
import java.util.List;

import games.moisoni.google_iab.BillingConnector;
import games.moisoni.google_iab.BillingEventListener;
import games.moisoni.google_iab.models.BillingResponse;
import games.moisoni.google_iab.models.PurchaseInfo;
import games.moisoni.google_iab.models.SkuInfo;


public class SubcriptionActivity extends AppCompatActivity {

    private static final String TAG = "UnlockAllActivity1";

    private SharedPref sharedPref;

    private BillingConnector billingConnector;

    RecyclerView list;
    InAppAdapter inAppAdapter;
    ArrayList<InApp> inApps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.subscription_activity);



        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        sharedPref = new SharedPref(this);

        list = findViewById(R.id.list_Subs);

        inApps = new ArrayList<>();

        list.setLayoutManager(new LinearLayoutManager(this));

        inAppAdapter = new InAppAdapter(inApps, new InAppAdapter.InAppAdapterListener() {
            @Override
            public void onItemClick(int pos, InApp inApp) {
                billingConnector.subscribe(SubcriptionActivity.this, inApp.getId());
            }
        });

        list.setAdapter(inAppAdapter);

        // Set up in - subs ----------------------------------------------------------------

        List<String> subscriptionIds = new ArrayList<>();
        subscriptionIds.add(Config.A_WEEK);
//        subscriptionIds.add(Config.A_MONTH);
//        subscriptionIds.add(Config.SIX_MONTH);


        billingConnector = new BillingConnector(this, Config.IAP_LISENCE_KEY) //"license_key" - public developer key from Play Console
                .setSubscriptionIds(subscriptionIds) //to set subscription ids - call only for subscription products
                .autoAcknowledge() //legacy option - better call this. Alternatively purchases can be acknowledge via public method "acknowledgePurchase(PurchaseInfo purchaseInfo)"
                .autoConsume() //legacy option - better call this. Alternatively purchases can be consumed via public method consumePurchase(PurchaseInfo purchaseInfo)"
                .enableLogging() //to enable logging for debugging throughout the library - this can be skipped
                .connect(); //to connect billing client with Play Console

        billingConnector.setBillingEventListener(new BillingEventListener() {
            @Override
            public void onProductsFetched(@NonNull List<SkuInfo> skuDetails) {
                String sku;
                String price;

                for (SkuInfo skuInfo : skuDetails) {
                    sku = skuInfo.getSku();
                    price = skuInfo.getPrice();

                    if (sku.equalsIgnoreCase(Config.A_WEEK)) {
                        inApps.add(new InApp(price, "Weekly Bundle", "Unlock this feature a week", sku));
                    } else if (sku.equalsIgnoreCase(Config.A_MONTH)) {
                        inApps.add(new InApp(price, "A Month Bundle", "Unlock this feature a month", sku));
                    } else if (sku.equalsIgnoreCase(Config.SIX_MONTH)) {
                        inApps.add(new InApp(price, "Six Months Bundle", "Unlock this feature 6 months", sku));
                    }
                }

                inAppAdapter.notifyDataSetChanged();
            }


            @Override
            public void onPurchasedProductsFetched(@NonNull List<PurchaseInfo> purchases) {
                Log.i(TAG, "onPurchasedProductsFetched: ");
                String sku;
                boolean isSub = false;
                for (PurchaseInfo purchaseInfo : purchases) {
                    sku = purchaseInfo.getSku();

                    if (sku.equalsIgnoreCase(Config.A_WEEK) || sku.equalsIgnoreCase(Config.A_MONTH) || sku.equalsIgnoreCase(Config.SIX_MONTH)) {
                        isSub = true;
                    }
                }

                sharedPref.setIsPremium(isSub);
            }

            @Override
            public void onProductsPurchased(@NonNull List<PurchaseInfo> purchases) {
                sharedPref.setIsPremium(true);
            }

            @Override
            public void onPurchaseAcknowledged(@NonNull PurchaseInfo purchase) {

            }

            @Override
            public void onPurchaseConsumed(@NonNull PurchaseInfo purchase) {

            }

            @Override
            public void onBillingError(@NonNull BillingConnector billingConnector, @NonNull BillingResponse response) {

            }
        });

        //------------------------------------------------------------------------------------------------
    }
}
