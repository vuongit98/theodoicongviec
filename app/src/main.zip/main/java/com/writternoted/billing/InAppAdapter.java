package com.writternoted.billing;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.writternoted.writternotedfree.R;

import java.util.ArrayList;


public class InAppAdapter extends RecyclerView.Adapter<InAppAdapter.ViewHolder> {

    private ArrayList<InApp> inApps;
    private InAppAdapterListener listener;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView title;
        private final TextView subtitle;
        private final TextView price;

        public ViewHolder(View view) {
            super(view);

            title = view.findViewById(R.id.title);
            subtitle = view.findViewById(R.id.subtitle);
            price = view.findViewById(R.id.price);
        }

        public TextView getTitle() {
            return title;
        }
        public TextView getSubtitle() {
            return subtitle;
        }

        public TextView getPrice() {
            return price;
        }
    }

    public InAppAdapter(ArrayList<InApp> inApps, InAppAdapterListener listener) {
        this.inApps = inApps;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_row_inapp, viewGroup, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, @SuppressLint("RecyclerView") final int position) {

        viewHolder.getTitle().setText(inApps.get(position).getTitle());
        viewHolder.getSubtitle().setText(inApps.get(position).getSubtitle());
        viewHolder.getPrice().setText(inApps.get(position).getPrice());
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(position, inApps.get(position));
            }
        });

    }

    @Override
    public int getItemCount() {
        return inApps.size();
    }

    public interface InAppAdapterListener {
        void onItemClick(int pos, InApp inApp);
    }
}

