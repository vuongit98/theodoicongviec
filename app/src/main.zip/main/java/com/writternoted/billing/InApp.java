package com.writternoted.billing;

public class InApp {
    String title;
    String price;
    String subtitle;
    String id;

    public InApp() {
    }

    public InApp(String price, String title, String subtitle, String id) {
        this.price = price;
        this.title = title;
        this.subtitle = subtitle;
        this.id = id;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }
}
