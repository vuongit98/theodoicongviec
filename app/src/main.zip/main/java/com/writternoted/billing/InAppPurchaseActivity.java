package com.writternoted.billing;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.writternoted.writternotedfree.R;

import java.util.ArrayList;
import java.util.List;

import games.moisoni.google_iab.BillingConnector;
import games.moisoni.google_iab.BillingEventListener;
import games.moisoni.google_iab.models.BillingResponse;
import games.moisoni.google_iab.models.PurchaseInfo;
import games.moisoni.google_iab.models.SkuInfo;

public class InAppPurchaseActivity extends AppCompatActivity {

    RecyclerView list;
    Toolbar toolbar;
    InAppAdapter inAppAdapter;
    ArrayList<InApp> inApps;
    TextView titleConsumer, titleNonConsumer;

    private SharedPref sharedPref;

    private BillingConnector billingConnector;

    public static final String TYPE_CONSUMER = "TYPE_CONSUMER";

    String type;
    private String TAG = "InAppPurchaseActivity";

    public static Intent open(Activity activity) {
        Intent intent = new Intent(activity, InAppPurchaseActivity.class);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in_app_purchase);

       findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               finish();
           }
       });



        list = findViewById(R.id.list_consumer);

        titleConsumer = findViewById(R.id.title_consumer);


        sharedPref = new SharedPref(this);

        inApps = new ArrayList<>();

        list.setLayoutManager(new LinearLayoutManager(this));

        inAppAdapter = new InAppAdapter(inApps, new InAppAdapter.InAppAdapterListener() {
            @Override
            public void onItemClick(int pos, InApp inApp) {
                billingConnector.purchase(InAppPurchaseActivity.this, inApp.getId());
            }
        });

        list.setAdapter(inAppAdapter);

        // ---------------------
        List<String> consumableIds = new ArrayList<>();
        consumableIds.add(Config.ITEM_1);
        consumableIds.add(Config.ITEM_2);
        consumableIds.add(Config.ITEM_3);
        consumableIds.add(Config.ITEM_4);
        consumableIds.add(Config.ITEM_5);

        billingConnector = new BillingConnector(this, Config.IAP_LISENCE_KEY)
                .setConsumableIds(consumableIds)
                .autoAcknowledge()
                .autoConsume()
                .enableLogging()
                .connect();

        billingListener();
    }

    private void billingListener() {
        billingConnector.setBillingEventListener(new BillingEventListener() {
            @Override
            public void onProductsFetched(@NonNull List<SkuInfo> skuDetails) {
                String sku;
                String price;

                for (SkuInfo skuInfo : skuDetails) {
                    sku = skuInfo.getSku();
                    price = skuInfo.getPrice();

                    if (sku.equalsIgnoreCase(Config.ITEM_1)) {
                        inApps.add(new InApp(price, "Donate us", "Click to donate", sku));
                    } else if (sku.equalsIgnoreCase(Config.ITEM_2)) {
                        inApps.add(new InApp(price, "Donate us", "Click to donate", sku));
                    } else if (sku.equalsIgnoreCase(Config.ITEM_3)) {
                        inApps.add(new InApp(price, "Donate us", "Click to donate", sku));
                    } else if (sku.equalsIgnoreCase(Config.ITEM_4)) {
                        inApps.add(new InApp(price, "Donate us", "Click to donate", sku));
                    } else if (sku.equalsIgnoreCase(Config.ITEM_5)) {
                        inApps.add(new InApp(price, "Donate us", "Click to donate", sku));
                    }
                }

                inAppAdapter.notifyDataSetChanged();
            }

            @Override
            public void onPurchasedProductsFetched(@NonNull List<PurchaseInfo> purchases) {

            }

            @Override
            public void onProductsPurchased(@NonNull List<PurchaseInfo> purchases) {
                String sku;

                for (PurchaseInfo purchaseInfo : purchases) {
                    sku = purchaseInfo.getSku();

                    if (sku.equalsIgnoreCase(Config.ITEM_1)) {
                        int totalCount1 = sharedPref.getTotalCount();
                        sharedPref.setTotalCount(totalCount1 + 5);
                    } else if (sku.equalsIgnoreCase(Config.ITEM_2)) {
                        int totalCount2 = sharedPref.getTotalCount();
                        sharedPref.setTotalCount(totalCount2 + 15);
                    } else if (sku.equalsIgnoreCase(Config.ITEM_3)) {
                        int totalCount3 = sharedPref.getTotalCount();
                        sharedPref.setTotalCount(totalCount3 + 30);
                    } else if (sku.equalsIgnoreCase(Config.ITEM_4)) {
                        int totalCount3 = sharedPref.getTotalCount();
                        sharedPref.setTotalCount(totalCount3 + 60);
                    } else if (sku.equalsIgnoreCase(Config.ITEM_5)) {
                        int totalCount3 = sharedPref.getTotalCount();
                        sharedPref.setTotalCount(totalCount3 + 120);
                    }
                }
            }

            @Override
            public void onPurchaseAcknowledged(@NonNull PurchaseInfo purchase) {

            }

            @Override
            public void onPurchaseConsumed(@NonNull PurchaseInfo purchase) {

            }

            @Override
            public void onBillingError(@NonNull BillingConnector billingConnector, @NonNull BillingResponse response) {

            }
        });
    }
}
