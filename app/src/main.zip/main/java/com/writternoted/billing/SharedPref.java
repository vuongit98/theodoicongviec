/*
 * Mint APP, Mint Console, Design (except icons and some open-source libraries) and Donut API is copyright of Rixhion, inc. - © Rixhion, inc 2019. All rights reserved.
 *
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 *  - YOU MAY USE, EDIT DATA INSIDE MINT ONLY.
 *
 * You may not, except with our express written permission, distribute or commercially exploit the content. Nor may you transmit it or store it in any other website & app or other form of electronic retrieval system.
 *
 */

package com.writternoted.billing;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;

import androidx.appcompat.app.AlertDialog;

public class SharedPref {

    private static SharedPref sharedPref;

    private SharedPreferences sharedPreferences;

    public static SharedPref getInstance(Context context) {
        if (sharedPref == null) {
            return new SharedPref(context);
        }
        return sharedPref;
    }

    /*---------------- Shared Pref ---------------*/
    public SharedPref(Context context) {

        sharedPreferences = context.getSharedPreferences("Yoga Shared Preferences", Context.MODE_PRIVATE);

    }

    /*---------------- Set Subscribe Notifications ---------------*/
    public void setIsPremium(Boolean state) {

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putBoolean("PremiumPlan", state);

        editor.apply();

    }


    /*---------------- Load Subscribe Notifications ---------------*/
    public Boolean isPremium() {

        return sharedPreferences.getBoolean("PremiumPlan", false);

    }


    public int getInAppItem1() {
        return sharedPreferences.getInt(Config.ITEM_1, 0);
    }

    public void setInAppItem1(int count) {
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt(Config.ITEM_1, count);

        editor.apply();
    }


    public int getInAppItem2() {
        return sharedPreferences.getInt(Config.ITEM_2, 0);
    }

    public void setInAppItem2(int count) {
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt(Config.ITEM_2, count);

        editor.apply();
    }

    public int getTotalCount() {
        return sharedPreferences.getInt(Config.TOTAL_COUNT, 0);
    }

    public void setTotalCount(int count) {
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt(Config.TOTAL_COUNT, count);

        editor.apply();
    }

    public int getInAppItem3() {
        return sharedPreferences.getInt(Config.ITEM_3, 0);
    }

    public void setInAppItem3(int count) {
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt(Config.ITEM_3, count);

        editor.apply();
    }

    public void setIsFreePlan(Boolean state) {

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putBoolean("FREE_PLAN", state);

        editor.apply();

    }


    public Boolean isFreePlan() {

        return sharedPreferences.getBoolean("FREE_PLAN", true);

    }

    public void sub() {
        int count = getTotalCount();
        setTotalCount(count - 1);
    }

    public boolean isOutOfMove() {
        return getTotalCount() <= 0;
    }

    public void showDialogReceive(Context context) {
        if (!isFreePlan()) {
            return;
        }
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

        alertDialogBuilder.setTitle("Congratulations!");

        alertDialogBuilder
                .setMessage("You get 10 free uses of premium feature (Mix Image).")
                .setCancelable(false)
                .setPositiveButton("Yes",
                        new DialogInterface.OnClickListener() {
                            @SuppressLint("NewApi")
                            public void onClick(DialogInterface dialog, int id) {
                                setTotalCount(10);
                                setIsFreePlan(false);
                                dialog.dismiss();
                            }
                        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void showDialogDonate(final Activity activity) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);

        alertDialogBuilder.setTitle("Important Notice");

        alertDialogBuilder
                .setMessage("Do you want to donate so that we can be motivated to develop the application?")
                .setCancelable(false)
                .setPositiveButton("Yes",
                        new DialogInterface.OnClickListener() {
                            @SuppressLint("NewApi")
                            public void onClick(DialogInterface dialog, int id) {
                                activity.startActivity(InAppPurchaseActivity.open(activity));
                            }
                        })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

}
